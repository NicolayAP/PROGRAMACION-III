package co.edu.uptc.controllerServer;

public interface IObserver {
    public void update();
}
